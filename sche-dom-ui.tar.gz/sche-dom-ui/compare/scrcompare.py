"""
PyCharm Pavel_Heraska@epam.com 08.08.2017 11:22 PM

SCRCOMPARE: Module which allows you to compare
two urls in different modes. First mode allows you to
compare two screenshots which created by selenium module
by their md5 hashes. Second one allows you to prepare images
to manual compare with highlighting different zones with red
color. For using this module just import check_pair() function
and call it from your code with needed params. To reduce HHDs space
issues dont forget to clean up results directory with clear_result_dir()
function.

"""
import requests
import os
import hashlib
import time
import uuid
import shutil
import imutils
import cv2
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from skimage.measure import compare_ssim


def get_status_code(url):
    """ This function return response code
    by receiving headers of given url
    used requests library
    :param url: String with url to get respose code
    :return: Returns response code or False if request return error.
    """
    try:
        r = requests.head(url)
        return r.status_code
    except StandardError:
        return False


def check_element_exists(browser):
    """
    After receiving page by url with selenium
    this function checks is there exists support bar
    on the page or not. Main reason is that support bar
    button moves on the page via javascript. And without
    clicking on it we cant receive static image to compare
    it.
    :param browser: Initialized selenium webdriver
    :return: If element exists return True else return False
    """
    try:
        if browser.find_element_by_id("support-bar"):
            return True
    except NoSuchElementException:
        return False


def check_slider_exists(browser):
    """
    After receiving page by url with selenium
    this function checks is there exists carousel
    on the page or not. Main reason is that carousel
    moves on the page via javascript. And without
    removing it we cant receive static image to compare
    it. Be careful because if you need to check carousel
    content don't use this function.
    :param browser: Initialized selenium webdriver
    :return: If element exists return True else return False
    """
    try:
        if browser.find_element_by_id("slider-new-v1"):
            return True
    except NoSuchElementException:
        return False


def clear_result_dir():
    """
    This function removes results directory
    with compared images which was created
    by manual mode of module.
    :return:
    """
    if os.path.exists("compare/static/results/"):
        shutil.rmtree("compare/static/results/")
    return True


def clear_unresolved_files():
    """
    Removing temporary image files after comparing
    :return: True
    """
    if os.path.exists('compare/static/link_proxy_to_compare.png'):
        os.remove('compare/static/link_proxy_to_compare.png')
    if os.path.exists('compare/static/link_native_to_compare.png'):
        os.remove('compare/static/link_native_to_compare.png')
    return True


def compare_images(link_proxy, link_native):
    """
    This function compare two images block by block
    and highlight difference in red color. Received images
    stored in results directory and could be used for
    future manual processing. URLs stored in links.txt
    in every single folder with compared files.
    :param link_proxy: Link proxy from check pair
    :param link_native: Link native from check pair
    :return: True
    """
    imageA = cv2.imread("compare/static/link_proxy_to_compare.png")
    imageB = cv2.imread("compare/static/link_native_to_compare.png")
    grayA = cv2.cvtColor(imageA, cv2.COLOR_BGR2GRAY)
    grayB = cv2.cvtColor(imageB, cv2.COLOR_BGR2GRAY)
    try:
        # score is value of identity between two images
        (score, diff) = compare_ssim(grayA, grayB, full=True)
        diff = (diff * 255).astype("uint8")
        thresh = cv2.threshold(diff, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
        cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = cnts[0] if imutils.is_cv2() else cnts[1]
        for c in cnts:
            (x, y, w, h) = cv2.boundingRect(c)
            cv2.rectangle(imageA, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.rectangle(imageB, (x, y), (x + w, y + h), (0, 0, 255), 2)
        unique_string = uuid.uuid4().hex
        os.makedirs("compare/static/results/" + str(unique_string))
        cv2.imwrite("compare/static/results/" + str(unique_string) + "/proxy_page_image.png", imageA)
        cv2.imwrite("compare/static/results/" + str(unique_string) + "/native_page_image.png", imageB)
        f = open("compare/static/results/" + str(unique_string) + "/links.txt", "a")
        f.write(str(link_proxy) + "\n" + str(link_native) + "\n")
        return {'state': "compare_ready", "score": score, "unique_id": str(unique_string)}
    except Exception, e:
        # prob will be needed in future
        err = str(e.message)
        return "err_img_size"


def check_pair(link_proxy, link_native, highlight_compare=False):
    """
    This function creates two images with help of
    selenium module. PhantomJS used for running in non X mode.
    Possible to use other selenium web drivers as (google chrome, firefox)
    but only on system with X. After creating two images they are comparing
    by getting md5 hash of received file. And remove files after comparing.
    Possible to remove sleep() functions if there no Ajax requests on the page to
    dynamically load content.
    :param link_proxy: First link to compare content
    :param link_native: Second link to compare content
    :param highlight_compare:  If param is true images with not equal md5 wil be saved and
    difference will be highlighted in red.
    :return: Return true if images equal. Return false if not.
    """
    browser = webdriver.PhantomJS()
    browser.set_window_size(1920, 1080)
    browser.get(link_proxy)
    time.sleep(1)
    if check_slider_exists(browser):
        browser.execute_script("$('#slider-new-v1').hide()")
        time.sleep(1)
    if check_element_exists(browser):
        browser.find_element_by_css_selector("[id=support-bar] label").click()
        time.sleep(1)
    browser.save_screenshot('compare/static/link_proxy_to_compare.png')
    browser.set_window_size(1920, 1080)
    browser.get(link_native)
    time.sleep(1)
    if check_slider_exists(browser):
        browser.execute_script("$('#slider-new-v1').hide()")
        time.sleep(1)
    if check_element_exists(browser):
        browser.find_element_by_css_selector("[id=support-bar] label").click()
        time.sleep(1)
    browser.save_screenshot('compare/static/link_native_to_compare.png')
    with open("compare/static/link_proxy_to_compare.png", "rb") as link_proxy_img:
        link_proxy_md5 = hashlib.md5(link_proxy_img.read()).hexdigest()
        link_proxy_img.close()
    with open("compare/static/link_native_to_compare.png", "rb") as link_native_img:
        link_native_md5 = hashlib.md5(link_native_img.read()).hexdigest()
        link_native_img.close()
    if link_proxy_md5 == link_native_md5:
        return "md5_success"
    else:
        if highlight_compare:
            return compare_images(link_proxy, link_native)
        else:
            return "md5_not_success"
