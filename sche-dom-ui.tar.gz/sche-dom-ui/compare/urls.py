from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^history/$', views.history, name='history'),
    url(r'^suspended/$', views.suspended, name='suspended'),
    url(r'^compare/$', views.compare, name='compare'),
    url(r'^validation/$', views.validation, name='validation'),
]
