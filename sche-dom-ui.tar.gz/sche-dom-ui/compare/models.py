from django.db import models

# Create your models here.


class Compare(models.Model):
    url_com = models.CharField(max_length=200)
    url_xyz = models.CharField(max_length=200)
    compare_state = models.BooleanField()
    img_xyz = models.CharField(max_length=200)
    img_com = models.CharField(max_length=200)
