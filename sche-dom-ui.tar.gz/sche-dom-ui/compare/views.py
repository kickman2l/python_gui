from django.shortcuts import render
from django.shortcuts import redirect
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse
from iframeval import validate_single_url
from scrcompare import check_pair
from scrcompare import clear_result_dir
from scrcompare import clear_unresolved_files
# Create your views here.


def index(request):
    return render(request, 'compare/compare.html')


def history(request):
    return render(request, 'compare/history.html')


def suspended(request):
    return render(request, 'compare/suspended.html')


def validation(request):
    if request.method == 'GET':
        return render(request, 'compare/validation.html')
    elif request.method == 'POST':
        if request.POST['link_to_compare']:
            url = request.POST['link_to_compare']
            data = validate_single_url(url)
            return render(request, 'compare/urlresult.html', locals())
        elif request.FILES:
            f = request.FILES['file_with_links']
            fs = FileSystemStorage()
            filename = fs.save("temp_links_file.txt", f)
            with open("temp_links_file.txt") as fl:
                content = fl.readlines()
            fs.delete("temp_links_file.txt")
            content = [x.strip() for x in content]
            return HttpResponse(content)
        else:
            no_input_data = True
            return render(request, 'compare/validation.html', locals())


def compare(request):
    if request.method == 'POST':
        to_compare = request.POST['link_to_compare']
        with_compare = request.POST['link_to_compare_with']
        clear_unresolved_files()
        clear_result_dir()
        data = check_pair(to_compare, with_compare, True)
        is_dict = type(data) is dict
        return render(request, 'compare/compareresult.html', locals())
    elif request.method == 'GET':
        return redirect('/')


