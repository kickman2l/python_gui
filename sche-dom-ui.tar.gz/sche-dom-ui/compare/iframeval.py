from selenium import webdriver
from operator import is_not
from functools import partial
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import re

unsafe_http = re.compile(r"^http:\/\/")

def get_usafe_link2(element, atr="src"):
    try:
        link = element.get_attribute(atr)
    except:
        return None
    else:
        if unsafe_http.search(element.get_attribute(atr)):
            return link
        else:
            return None

def get_usafe_css2(element, rel="stylesheet", atr="href"):
    try:
        link = element.get_attribute(atr)
    except:
        return None
    else:
        if unsafe_http.search(element.get_attribute(atr)) and element.get_attribute("rel") == 'stylesheet':
            return link
        else:
            return None

def validate_single_url(url):
    # unsafe_http = re.compile(r"^http:\/\/")
    caps = DesiredCapabilities.PHANTOMJS
    caps[
        "phantomjs.page.settings.userAgent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36"
    driver = webdriver.PhantomJS(desired_capabilities=caps)
    driver.set_window_size(1920, 1080)  # optional
    driver.get(url)
    # get_usafe_link = lambda element, atr="src": element.get_attribute(atr) if unsafe_http.search(
    #     element.get_attribute(atr)) else None
    iframes = driver.find_elements_by_tag_name("iframe")
    images = driver.find_elements_by_tag_name("img")
    scripts = driver.find_elements_by_tag_name("script")
    links = driver.find_elements_by_tag_name("link")

    iframes_res = map(get_usafe_link2, iframes)
    images_res = map(get_usafe_link2, images)
    scripts_res = map(get_usafe_link2, scripts)
    css_res = map(get_usafe_css2, links)
    # css_res = get_stylesheets(url)
    return {'iframes': clear_list(iframes_res), 'images': clear_list(images_res), 'scripts': clear_list(scripts_res), 'css': clear_list(css_res)}


def clear_list(lst):
    return filter(partial(is_not, None), lst)


# def get_stylesheets(url):
#     return ["http://examplelinks.com/style1/style1/style1"]

# with open('src.txt') as f:
#     src_links = f.read().splitlines()
# driver.save_screenshot('screen.png') # save a screenshot to disk

# driver.get('https://www.schneider-electric.com.hk/en/work/campaign/innovation/overview.jsp')
# driver.get('http://www.schneider-electric.com.hk/en/work/services/training/technical-training.jsp')

# for elem in iframes:
# 	print (get_usafe_link(elem))

# scripts = driver.find_elements_by_tag_name("script")
# print ("scripts")
# for elem in scripts:
# 	if unsafe_http.search(elem.get_attribute("src")):
#   		print ('found mixed content: ', elem.get_attribute("src"))

# css_links = driver.find_elements_by_tag_name("link")
# print ("css links")
# for elem in css_links:
# 	if unsafe_http.search(elem.get_attribute("href")) and elem.get_attribute("rel") == 'stylesheet':
#   		print ('found mixed content: ', elem.get_attribute("href"))

# external_links = driver.find_elements_by_tag_name("link")
# print ("external links")
# for elem in external_links:
# 	if unsafe_http.search(elem.get_attribute("href")) and elem.get_attribute("rel") != 'stylesheet':
#   		print ('found mixed content: ', elem.get_attribute("href"))

# external_links = driver.find_elements_by_tag_name("a")
# print ("external links2")
# for elem in external_links:
# 	if unsafe_http.search(elem.get_attribute("href")):
#   		print ('found mixed content: ', elem.get_attribute("href"))
